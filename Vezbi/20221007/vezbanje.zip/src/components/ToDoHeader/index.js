import React from "react";
import "./index.css";

function ToDoHeader({ title }) {
  return <div>{title}</div>;
}

export default ToDoHeader;
