import React, { useState } from "react";
import ToDoList from "./pages/ToDoList";

function App() {
  // const [count, setCount] = useState(0); // count = 0
  // const buttons = [
  //   { sign: "+", number: 1 },
  //   { sign: "-", number: 1 },
  //   { sign: "*", number: 2 },
  //   { sign: "/", number: 2 },
  //   { sign: "%", number: 2 },
  // ];
  // const handleChange = (type, number) => {
  //   setCount(getValue(count, type, number));
  // };

  // const getValue = (value, type, number) => {
  //   switch (type) {
  //     case "+":
  //       return value + number;
  //     case "-":
  //       return value - number;
  //     case "*":
  //       return value * number;
  //     case "/":
  //       return value / number;
  //     case "%":
  //       return value % number;
  //   }
  //   return value;
  // };

  return (
    <>
      <ToDoList />
      {/* {count}

      {buttons.map(({ sign, number }) => {
        return (
          <button key={sign} onClick={() => handleChange(sign, number)}>
            {sign}
            {number}
          </button>
        );
      })} */}
    </>
  );
}

export default App;

// const handleStateChangeAdd = () => {
//   setCount(count + 1);
// };

// const handleStateChangeMinus = () => {
//   setCount(count - 1);
// };

// const handleStateChangeMulty = () => {
//   setCount(count * 2);
// };

// const handleStateChangeDelenje = () => {
//   setCount(count / 2);
// };

// const handleStateChangeModul = () => {
//   setCount(count % 2);
// };
